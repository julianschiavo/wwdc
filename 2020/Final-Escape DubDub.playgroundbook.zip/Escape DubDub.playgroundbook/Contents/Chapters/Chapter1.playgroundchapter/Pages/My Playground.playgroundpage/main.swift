/*:
# **📦 Escape DubDub**

Escape DubDub is a fun recreation of an escape room in AR, allowing you to experience exciting puzzles and challenges similar to a real escape room from the comfort of your home.


While you play, learn about some key Computer Science concepts linked to the puzzles. This game is targeted towards young teenagers who are interested in learning more about CS.


Tap the Run My Code button to play.

---

- Important:
You are recommended to play in full screen, holding the iPad horizontally. As I do not have an iPad Pro, I was not able to test it on one personally. I'd really appreciate if you could use an iPad (6th generation) or iPad (7th generation). Otherwise, please try to run it multiple times or switch from full screen to split screen by dragging the handle if it doesn't work. Thank you!

---

### 🪑 AR Tips
For the best AR experience, point your iPad down to a large, flat surface while standing up. When shown on screen, move your iPad back and forth while rotating it to start.

### 🔊 Accessibility
Audio is required to complete the game. You can disable audio for accessibility or other reasons by tapping Disable when the Accessibility screen is shown.



 */
//#-hidden-code
import PlaygroundSupport
import SwiftUI
import UIKit

PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code


let baseView = BaseView()
PlaygroundPage.current.setLiveView(baseView)










































































//#-code-completion(everything, hide)
/*#-editable-code*//*#-end-editable-code*/
