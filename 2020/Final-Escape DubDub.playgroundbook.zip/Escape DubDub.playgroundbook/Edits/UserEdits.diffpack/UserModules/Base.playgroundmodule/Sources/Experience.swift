//
// Experience.swift
// GENERATED CONTENT. DO NOT EDIT.
//

import Foundation
import RealityKit
import simd
import Combine

public enum Experience {
    
    public enum LoadRealityFileError: Error {
        case fileNotFound(String)
    }
    
    private static var streams = [Combine.AnyCancellable]()
    
    public static func loadMorseCode() throws -> Experience.MorseCode {
        guard let realityFileURL = Foundation.Bundle(for: Experience.MorseCode.self).url(forResource: "Experience", withExtension: "reality") else {
            throw Experience.LoadRealityFileError.fileNotFound("Experience.reality")
        }
        
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Morse Code", isDirectory: false)
        let anchorEntity = try Experience.MorseCode.loadAnchor(contentsOf: realityFileSceneURL)
        return createMorseCode(from: anchorEntity)
    }
    
    public static func loadMorseCodeAsync(completion: @escaping (Swift.Result<Experience.MorseCode, Swift.Error>) -> Void) {
        guard let realityFileURL = Foundation.Bundle(for: Experience.MorseCode.self).url(forResource: "Experience", withExtension: "reality") else {
            completion(.failure(Experience.LoadRealityFileError.fileNotFound("Experience.reality")))
            return
        }
        
        var cancellable: Combine.AnyCancellable?
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Morse Code", isDirectory: false)
        let loadRequest = Experience.MorseCode.loadAnchorAsync(contentsOf: realityFileSceneURL)
        cancellable = loadRequest.sink(receiveCompletion: { loadCompletion in
            if case let .failure(error) = loadCompletion {
                completion(.failure(error))
            }
            streams.removeAll { $0 === cancellable }
        }, receiveValue: { entity in
            completion(.success(Experience.createMorseCode(from: entity)))
        })
        cancellable?.store(in: &streams)
    }
    
    private static func createMorseCode(from anchorEntity: RealityKit.AnchorEntity) -> Experience.MorseCode {
        let morseCode = Experience.MorseCode()
        morseCode.anchoring = anchorEntity.anchoring
        morseCode.addChild(anchorEntity)
        return morseCode
    }
    
    public static func loadPuzzle() throws -> Experience.Puzzle {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Puzzle.self).url(forResource: "Experience", withExtension: "reality") else {
            throw Experience.LoadRealityFileError.fileNotFound("Experience.reality")
        }
        
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Puzzle", isDirectory: false)
        let anchorEntity = try Experience.Puzzle.loadAnchor(contentsOf: realityFileSceneURL)
        return createPuzzle(from: anchorEntity)
    }
    
    public static func loadPuzzleAsync(completion: @escaping (Swift.Result<Experience.Puzzle, Swift.Error>) -> Void) {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Puzzle.self).url(forResource: "Experience", withExtension: "reality") else {
            completion(.failure(Experience.LoadRealityFileError.fileNotFound("Experience.reality")))
            return
        }
        
        var cancellable: Combine.AnyCancellable?
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Puzzle", isDirectory: false)
        let loadRequest = Experience.Puzzle.loadAnchorAsync(contentsOf: realityFileSceneURL)
        cancellable = loadRequest.sink(receiveCompletion: { loadCompletion in
            if case let .failure(error) = loadCompletion {
                completion(.failure(error))
            }
            streams.removeAll { $0 === cancellable }
        }, receiveValue: { entity in
            completion(.success(Experience.createPuzzle(from: entity)))
        })
        cancellable?.store(in: &streams)
    }
    
    private static func createPuzzle(from anchorEntity: RealityKit.AnchorEntity) -> Experience.Puzzle {
        let puzzle = Experience.Puzzle()
        puzzle.anchoring = anchorEntity.anchoring
        puzzle.addChild(anchorEntity)
        return puzzle
    }
    
    public static func loadMastermind() throws -> Experience.Mastermind {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Mastermind.self).url(forResource: "Experience", withExtension: "reality") else {
            throw Experience.LoadRealityFileError.fileNotFound("Experience.reality")
        }
        
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Mastermind", isDirectory: false)
        let anchorEntity = try Experience.Mastermind.loadAnchor(contentsOf: realityFileSceneURL)
        return createMastermind(from: anchorEntity)
    }
    
    public static func loadMastermindAsync(completion: @escaping (Swift.Result<Experience.Mastermind, Swift.Error>) -> Void) {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Mastermind.self).url(forResource: "Experience", withExtension: "reality") else {
            completion(.failure(Experience.LoadRealityFileError.fileNotFound("Experience.reality")))
            return
        }
        
        var cancellable: Combine.AnyCancellable?
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Mastermind", isDirectory: false)
        let loadRequest = Experience.Mastermind.loadAnchorAsync(contentsOf: realityFileSceneURL)
        cancellable = loadRequest.sink(receiveCompletion: { loadCompletion in
            if case let .failure(error) = loadCompletion {
                completion(.failure(error))
            }
            streams.removeAll { $0 === cancellable }
        }, receiveValue: { entity in
            completion(.success(Experience.createMastermind(from: entity)))
        })
        cancellable?.store(in: &streams)
    }
    
    private static func createMastermind(from anchorEntity: RealityKit.AnchorEntity) -> Experience.Mastermind {
        let mastermind = Experience.Mastermind()
        mastermind.anchoring = anchorEntity.anchoring
        mastermind.addChild(anchorEntity)
        return mastermind
    }
    
    public static func loadPadSort() throws -> Experience.PadSort {
        guard let realityFileURL = Foundation.Bundle(for: Experience.PadSort.self).url(forResource: "Experience", withExtension: "reality") else {
            throw Experience.LoadRealityFileError.fileNotFound("Experience.reality")
        }
        
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Pad Sort", isDirectory: false)
        let anchorEntity = try Experience.PadSort.loadAnchor(contentsOf: realityFileSceneURL)
        return createPadSort(from: anchorEntity)
    }
    
    public static func loadPadSortAsync(completion: @escaping (Swift.Result<Experience.PadSort, Swift.Error>) -> Void) {
        guard let realityFileURL = Foundation.Bundle(for: Experience.PadSort.self).url(forResource: "Experience", withExtension: "reality") else {
            completion(.failure(Experience.LoadRealityFileError.fileNotFound("Experience.reality")))
            return
        }
        
        var cancellable: Combine.AnyCancellable?
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Pad Sort", isDirectory: false)
        let loadRequest = Experience.PadSort.loadAnchorAsync(contentsOf: realityFileSceneURL)
        cancellable = loadRequest.sink(receiveCompletion: { loadCompletion in
            if case let .failure(error) = loadCompletion {
                completion(.failure(error))
            }
            streams.removeAll { $0 === cancellable }
        }, receiveValue: { entity in
            completion(.success(Experience.createPadSort(from: entity)))
        })
        cancellable?.store(in: &streams)
    }
    
    private static func createPadSort(from anchorEntity: RealityKit.AnchorEntity) -> Experience.PadSort {
        let padSort = Experience.PadSort()
        padSort.anchoring = anchorEntity.anchoring
        padSort.addChild(anchorEntity)
        return padSort
    }
    
    public static func loadCodebreaking() throws -> Experience.Codebreaking {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Codebreaking.self).url(forResource: "Experience", withExtension: "reality") else {
            throw Experience.LoadRealityFileError.fileNotFound("Experience.reality")
        }
        
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Codebreaking", isDirectory: false)
        let anchorEntity = try Experience.Codebreaking.loadAnchor(contentsOf: realityFileSceneURL)
        return createCodebreaking(from: anchorEntity)
    }
    
    public static func loadCodebreakingAsync(completion: @escaping (Swift.Result<Experience.Codebreaking, Swift.Error>) -> Void) {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Codebreaking.self).url(forResource: "Experience", withExtension: "reality") else {
            completion(.failure(Experience.LoadRealityFileError.fileNotFound("Experience.reality")))
            return
        }
        
        var cancellable: Combine.AnyCancellable?
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Codebreaking", isDirectory: false)
        let loadRequest = Experience.Codebreaking.loadAnchorAsync(contentsOf: realityFileSceneURL)
        cancellable = loadRequest.sink(receiveCompletion: { loadCompletion in
            if case let .failure(error) = loadCompletion {
                completion(.failure(error))
            }
            streams.removeAll { $0 === cancellable }
        }, receiveValue: { entity in
            completion(.success(Experience.createCodebreaking(from: entity)))
        })
        cancellable?.store(in: &streams)
    }
    
    private static func createCodebreaking(from anchorEntity: RealityKit.AnchorEntity) -> Experience.Codebreaking {
        let codebreaking = Experience.Codebreaking()
        codebreaking.anchoring = anchorEntity.anchoring
        codebreaking.addChild(anchorEntity)
        return codebreaking
    }
    
    public static func loadCongratulations() throws -> Experience.Congratulations {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Congratulations.self).url(forResource: "Experience", withExtension: "reality") else {
            throw Experience.LoadRealityFileError.fileNotFound("Experience.reality")
        }
        
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Congratulations", isDirectory: false)
        let anchorEntity = try Experience.Congratulations.loadAnchor(contentsOf: realityFileSceneURL)
        return createCongratulations(from: anchorEntity)
    }
    
    public static func loadCongratulationsAsync(completion: @escaping (Swift.Result<Experience.Congratulations, Swift.Error>) -> Void) {
        guard let realityFileURL = Foundation.Bundle(for: Experience.Congratulations.self).url(forResource: "Experience", withExtension: "reality") else {
            completion(.failure(Experience.LoadRealityFileError.fileNotFound("Experience.reality")))
            return
        }
        
        var cancellable: Combine.AnyCancellable?
        let realityFileSceneURL = realityFileURL.appendingPathComponent("Congratulations", isDirectory: false)
        let loadRequest = Experience.Congratulations.loadAnchorAsync(contentsOf: realityFileSceneURL)
        cancellable = loadRequest.sink(receiveCompletion: { loadCompletion in
            if case let .failure(error) = loadCompletion {
                completion(.failure(error))
            }
            streams.removeAll { $0 === cancellable }
        }, receiveValue: { entity in
            completion(.success(Experience.createCongratulations(from: entity)))
        })
        cancellable?.store(in: &streams)
    }
    
    private static func createCongratulations(from anchorEntity: RealityKit.AnchorEntity) -> Experience.Congratulations {
        let congratulations = Experience.Congratulations()
        congratulations.anchoring = anchorEntity.anchoring
        congratulations.addChild(anchorEntity)
        return congratulations
    }
    
    public class MorseCode: RealityKit.Entity, RealityKit.HasAnchoring {
        
        public var fixedMorse: RealityKit.Entity? {
            return self.findEntity(named: "fixed-morse")
        }
        
        public var fixedSlab: RealityKit.Entity? {
            return self.findEntity(named: "fixed-slab")
        }
        
        public var fixedSound: RealityKit.Entity? {
            return self.findEntity(named: "fixed-sound")
        }
        
        public var fixedText: RealityKit.Entity? {
            return self.findEntity(named: "fixed-text")
        }
        
    }
    
    public class Puzzle: RealityKit.Entity, RealityKit.HasAnchoring {
        
        public var puzzlePieceEntities: [RealityKit.Entity] {
            return self.findAllEntities(named: "puzzle-piece")
        }
        
        private func findAllEntities(named name: Swift.String) -> [RealityKit.Entity] {
            var entities = [RealityKit.Entity]()
            
            func matchEntity(root: RealityKit.Entity) {
                if root.name == name {
                    entities.append(root)
                }
                
                for child in root.children {
                    matchEntity(root: child)
                }
            }
            
            matchEntity(root: self)
            
            return entities
        }
        
    }
    
    public class Mastermind: RealityKit.Entity, RealityKit.HasAnchoring {
        
        public var fixedBall1: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball1")
        }
        
        public var fixedBall2: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball2")
        }
        
        public var fixedBall3: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball3")
        }
        
        public var fixedBall4: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball4")
        }
        
        public var fixedBase: RealityKit.Entity? {
            return self.findEntity(named: "fixed-base")
        }
        
    }
    
    public class PadSort: RealityKit.Entity, RealityKit.HasAnchoring {
        
        public var fixedBall1: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball1")
        }
        
        public var fixedBall2: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball2")
        }
        
        public var fixedBall3: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball3")
        }
        
        public var fixedBall4: RealityKit.Entity? {
            return self.findEntity(named: "fixed-ball4")
        }
        
        public var fixedBlock1: RealityKit.Entity? {
            return self.findEntity(named: "fixed-block1")
        }
        
        public var fixedBlock2: RealityKit.Entity? {
            return self.findEntity(named: "fixed-block2")
        }
        
        public var fixedBlock3: RealityKit.Entity? {
            return self.findEntity(named: "fixed-block3")
        }
        
        public var fixedBlock4: RealityKit.Entity? {
            return self.findEntity(named: "fixed-block4")
        }
        
    }
    
    public class Codebreaking: RealityKit.Entity, RealityKit.HasAnchoring {
        
        public var fixedImposterEntities: [RealityKit.Entity] {
            return self.findAllEntities(named: "fixed-imposter")
        }
        
        public var fixedRotatedSlab: RealityKit.Entity? {
            return self.findEntity(named: "fixed-rotated-slab")
        }
        
        public var fixedShiny: RealityKit.Entity? {
            return self.findEntity(named: "fixed-shiny")
        }
        
        public var fixedSlab: RealityKit.Entity? {
            return self.findEntity(named: "fixed-slab")
        }
        
        public var fixedStickerEntities: [RealityKit.Entity] {
            return self.findAllEntities(named: "fixed-sticker")
        }
        
        private func findAllEntities(named name: Swift.String) -> [RealityKit.Entity] {
            var entities = [RealityKit.Entity]()
            
            func matchEntity(root: RealityKit.Entity) {
                if root.name == name {
                    entities.append(root)
                }
                
                for child in root.children {
                    matchEntity(root: child)
                }
            }
            
            matchEntity(root: self)
            
            return entities
        }
        
    }
    
    public class Congratulations: RealityKit.Entity, RealityKit.HasAnchoring {
        
    }
    
}
